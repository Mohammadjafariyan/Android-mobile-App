package service.models;

public class AAWebViewModel extends  BaseViewModel{

}
