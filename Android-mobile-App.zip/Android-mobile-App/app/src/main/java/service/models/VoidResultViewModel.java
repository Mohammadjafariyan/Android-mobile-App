package service.models;

public class VoidResultViewModel  extends  BaseViewModel {



}
