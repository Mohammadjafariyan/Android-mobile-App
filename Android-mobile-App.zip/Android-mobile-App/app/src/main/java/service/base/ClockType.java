package service.base;

public enum ClockType{
    GPS,CameraSelfie, QRCode, Wifi

}
