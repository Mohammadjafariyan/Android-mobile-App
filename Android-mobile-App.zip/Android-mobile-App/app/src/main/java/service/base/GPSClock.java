package service.base;

public class GPSClock {
}
