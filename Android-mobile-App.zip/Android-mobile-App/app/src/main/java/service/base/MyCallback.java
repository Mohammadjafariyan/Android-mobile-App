package service.base;

public interface MyCallback {
     void Callback(Object o) throws Exception;
}
