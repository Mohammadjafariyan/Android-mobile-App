package service.models;

public class ClockInViewModelResult
        extends  BaseViewModel {
    public ClockInViewModelResult() {

    }
    public ClockInViewModelResult(String s) {

    }

}
