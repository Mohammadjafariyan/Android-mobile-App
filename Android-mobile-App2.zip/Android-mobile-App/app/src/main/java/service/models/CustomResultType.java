package service.models;

public enum CustomResultType
{
    success,
    fail
}
